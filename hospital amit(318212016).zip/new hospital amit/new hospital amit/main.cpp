#pragma warning (disable: 4996)
#include <iostream>
#include "Doctor.h"
#include "Nurse.h"
#include "Hospital.h"
#include "Controller.h"
#include "Article.h"
#include "Researcher.h"
#include "ResearchInstitute.h"
using namespace std;


int main()
{
	menu();

}

