//#include "Surgeon.h"
//
//// Constructor
//Surgeon::Surgeon(const string& name, const string& specialty, const string& department, int numOperations)
//    : Doctor(name, specialty, department), numOperations(numOperations) {
//}
//
//// Print function override
//void Surgeon::print() const {
//    cout << "Surgeon: " << getName()
//        << ", Specialty: " << getSpecialty()
//        << ", Department: " << getDepartment()
//        << ", Operations performed: " << numOperations
//        << endl;
//}
