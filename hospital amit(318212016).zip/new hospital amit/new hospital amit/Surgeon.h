//#pragma warning (disable: 4996)
//#ifndef __SURGEON_H
//#define __SURGEON_H
//
//#include "Doctor.h"
//
//class Surgeon : public Doctor {
//private:
//    int numOperations;
//
//public:
//    Surgeon(const string& name, const string& specialty, const string& department, int numOperations);
//
//    void setNumOperations(int num) { numOperations = num; }
//    int getNumOperations() const { return numOperations; }
//
//    void print() const override;
//    Employee* clone() const override { return new Surgeon(*this); }
//};

#endif
